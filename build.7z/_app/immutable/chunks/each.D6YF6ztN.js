function u(n){return(n==null?void 0:n.length)!==void 0?n:Array.from(n)}export{u as e};

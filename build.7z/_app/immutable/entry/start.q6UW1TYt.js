import{a as t}from"../chunks/entry.B29USIMw.js";export{t as start};
